﻿{
	"token": "MTAwOTQwMTA0MTU2MjkxNDg0Nw.GLsfyx.Y_ap5Q8kOvq4jMUgu_1O7qy-inrS9wLVgMnXJk",
	"roleID": "1010905946286985398",
	"versionbot": "⚡ SPAM SMS V2 ⚡",
	"img": "https://i.imgur.com/TXVGIzn.jpg"
}