# Đây Chỉ Là Main DDos Chưa Có Methods , Hãy Sử Dụng Cái Đầu Để Code Thêm methods !

![screenshot_1667619987](https://user-images.githubusercontent.com/112190071/200099485-618d9760-18bc-4587-b2d5-e5b49aa69a4f.png)
